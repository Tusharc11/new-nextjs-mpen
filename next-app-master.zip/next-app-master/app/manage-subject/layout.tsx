export default function ManageSubjectLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    return <>{children}</>;
}