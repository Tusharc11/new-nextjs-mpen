export default function ManageCourseLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    return <>{children}</>;
}