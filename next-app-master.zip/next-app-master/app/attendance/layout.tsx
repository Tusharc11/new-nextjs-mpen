export default function AttendanceLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    return <>{children}</>;
}