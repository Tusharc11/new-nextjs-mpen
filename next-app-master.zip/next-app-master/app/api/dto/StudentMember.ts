export interface StudentMemberDTO {
    _id: number;
    firstName: string;
    lastName: string;
    class: string;
    section: string;
    email: string;
    address: string;
    lastLogin: string;
    dateJoined: string;
}
