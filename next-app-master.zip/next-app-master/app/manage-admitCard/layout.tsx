export default function ManageAdmitCardLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    return <>{children}</>;
}