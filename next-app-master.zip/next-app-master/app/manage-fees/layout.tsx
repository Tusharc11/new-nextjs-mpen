export default function ManageFeesLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    return <>{children}</>;
}