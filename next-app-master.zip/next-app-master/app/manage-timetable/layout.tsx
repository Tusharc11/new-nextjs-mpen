export default function ManageTimetableLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    return <>{children}</>;
}