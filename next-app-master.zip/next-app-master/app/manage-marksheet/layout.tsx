export default function ManageResultLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    return <>{children}</>;
}