import LoginPage from "./login/page";

export default function Home() {
  return (
    <main>
      <LoginPage/>
    </main>
  )
}
