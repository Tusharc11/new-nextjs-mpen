export default function ManageStudentLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    return <>{children}</>;
}