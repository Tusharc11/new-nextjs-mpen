export default function ManageTransportLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    return <>{children}</>;
}