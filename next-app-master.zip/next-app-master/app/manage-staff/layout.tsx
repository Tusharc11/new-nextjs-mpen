// app/manage-staff/layout.tsx
export default function ManageStaffLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    return <>{children}</>;
}