export default function ManageLeaveLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    return <>{children}</>;
}